//
//  IOLEnvironment
//  INFOnlineLibrary
//
//  Created by Sebastian Homscheidt on 03.07.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#define IOLDeprecated(ver, msg) __attribute__((deprecated("Deprecated in INFOnline " #ver " for iOS. " msg)))
